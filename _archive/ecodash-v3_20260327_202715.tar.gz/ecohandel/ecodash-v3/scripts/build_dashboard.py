#!/usr/bin/env python3
import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "dashboard" / "data"
OUT = ROOT / "dashboard" / "index.html"


def load(name):
    return json.loads((DATA_DIR / name).read_text())


def amount_from_currency(value: str) -> float:
    if not value or value == "-":
        return 0.0
    cleaned = value.replace("€", "").replace(".", "").replace(",", ".").strip()
    try:
        return float(cleaned)
    except Exception:
        return 0.0


def number_from_text(value: str) -> float:
    if not value or value == "-":
        return 0.0
    cleaned = value.replace(".", "").replace(",", ".").replace("%", "").replace("x", "").strip()
    try:
        return float(cleaned)
    except Exception:
        return 0.0


def compact(value: float) -> str:
    if abs(value - round(value)) < 0.001:
        return f"{int(round(value)):,}".replace(",", ".")
    return f"{value:,.1f}".replace(",", "X").replace(".", ",").replace("X", ".")


def kpi_cards(items):
    parts = []
    for item in items:
        tone = item.get("tone", "neutral")
        parts.append(
            f'''<div class="kpi-card tone-{tone}"><div class="kpi-label">{item["label"]}</div><div class="kpi-value">{item["value"]}</div></div>'''
        )
    return "\n".join(parts)


def list_items(items, key="detail"):
    if not items:
        return '<div class="empty">Nog geen data.</div>'
    rows = []
    for item in items:
        if isinstance(item, str):
            rows.append(f"<li>{item}</li>")
        else:
            lead = item.get("type") or item.get("name") or "Item"
            detail = item.get(key) or item.get("focus") or item.get("risk") or ""
            extra = item.get("status")
            suffix = f' <span class="chip">{extra}</span>' if extra else ""
            rows.append(f"<li><strong>{lead}</strong>{suffix}<div class=\"sub\">{detail}</div></li>")
    return "<ul class=\"stack\">" + "".join(rows) + "</ul>"


def windows_table(windows: dict, kind: str):
    if not windows:
        return '<div class="empty">Nog geen periodes beschikbaar.</div>'
    headers = {
        "ads": ["Periode", "Spend", "Value", "Clicks", "CTR"],
        "gsc": ["Periode", "Clicks", "Impressions", "CTR", "Avg pos"],
        "ga4": ["Periode", "Sessions", "Users", "Revenue"],
        "shopify": ["Periode", "Revenue", "Orders", "AOV"],
    }
    rows_html = []
    order = ["today", "yesterday", "last_7_days", "last_28_days"]
    for key in order:
        row = windows.get(key)
        if not row:
            continue
        if kind == "ads":
            cols = [row.get("label", key), row.get("cost_eur", "-"), row.get("value_eur", "-"), row.get("clicks", "-"), row.get("ctr", "-")]
        elif kind == "gsc":
            cols = [row.get("label", key), row.get("clicks_fmt", "-"), row.get("impressions_fmt", "-"), row.get("ctr_fmt", "-"), row.get("position_fmt", "-")]
        elif kind == "ga4":
            cols = [row.get("label", key), row.get("sessions_fmt", "-"), row.get("active_users_fmt", "-"), row.get("revenue_fmt", "-")]
        else:
            cols = [row.get("label", key), row.get("revenue_fmt", "-"), row.get("orders_fmt", "-"), row.get("aov_fmt", "-")]
        rows_html.append("<tr>" + "".join(f"<td>{c}</td>" for c in cols) + "</tr>")
    ths = "".join(f"<th>{h}</th>" for h in headers[kind])
    return f'<table class="mini-table"><thead><tr>{ths}</tr></thead><tbody>{"".join(rows_html)}</tbody></table>'


def status_badge(payload):
    status = payload.get("status", "unknown")
    return f'<div class="status status-{status}">{status}</div>'


def section(title, eyebrow, payload, detail_html):
    return f'''
    <section class="panel span-6">
      <div class="panel-head">
        <div>
          <div class="eyebrow">{eyebrow}</div>
          <h2>{title}</h2>
        </div>
        {status_badge(payload)}
      </div>
      <div class="kpi-grid">{kpi_cards(payload.get("kpis", []))}</div>
      <div class="detail-grid">{detail_html}</div>
      <div class="stamp">Last data touch: {payload.get("fetched_at", "-")}</div>
    </section>
    '''


def build_signals(ads, gsc, ga4, shopify):
    signals = []
    ads_spend_7d = amount_from_currency(ads["windows"].get("last_7_days", {}).get("cost_eur", "€0,00"))
    ads_value_7d = amount_from_currency(ads["windows"].get("last_7_days", {}).get("value_eur", "€0,00"))
    shop_revenue_28d = amount_from_currency(shopify["windows"].get("last_28_days", {}).get("revenue_fmt", "€0,00"))
    ga4_rev_28d = amount_from_currency(ga4["windows"].get("last_28_days", {}).get("revenue_fmt", "€0,00"))
    ga4_sessions_7d = number_from_text(ga4["windows"].get("last_7_days", {}).get("sessions_fmt", "0"))
    shop_orders_28d = number_from_text(shopify["windows"].get("last_28_days", {}).get("orders_fmt", "0"))
    gsc_clicks_28d = number_from_text(gsc["windows"].get("last_28_days", {}).get("clicks_fmt", "0"))

    if ads_spend_7d > 0 and ads_value_7d == 0:
        signals.append({
            "tone": "warn",
            "title": "Ads geeft spend door, maar geen omzetwaarde",
            "detail": f"Laatste 7 dagen: spend €{compact(ads_spend_7d)} en conversion value €0,00. Purchase value sanity check is nog steeds prioriteit #1."
        })

    if shop_revenue_28d > 0 and ga4_rev_28d == 0:
        signals.append({
            "tone": "warn",
            "title": "GA4 omzet loopt achter op Shopify",
            "detail": f"Shopify laat €{compact(shop_revenue_28d)} omzet in 28 dagen zien, terwijl GA4 nog €0,00 terugstuurt. E-commerce revenue mapping verdient een check."
        })

    if ga4_sessions_7d > 0 and shop_orders_28d <= 1:
        signals.append({
            "tone": "neutral",
            "title": "Verkeer staat, commerciële conversie is nog dun",
            "detail": f"GA4 ziet {compact(ga4_sessions_7d)} sessies in 7 dagen, maar Shopify ziet slechts {compact(shop_orders_28d)} order in 28 dagen. Goede plek voor UX / offer / trust checks."
        })

    if gsc_clicks_28d > 100:
        signals.append({
            "tone": "good",
            "title": "SEO begint al tractie te geven",
            "detail": f"GSC toont {compact(gsc_clicks_28d)} clicks in 28 dagen. Dat is genoeg volume om query-winnaars en product-landers actief te gaan uitbouwen."
        })

    if not signals:
        signals.append({"tone": "good", "title": "Alle databronnen zijn live", "detail": "Geen grote blokkades meer. Tijd om op groei- en winstsignalen te sturen."})
    return signals


def executive_cards(ads, gsc, ga4, shopify):
    ads_spend_7d = ads["windows"].get("last_7_days", {}).get("cost_eur", "€0,00")
    shop_rev_28d = shopify["windows"].get("last_28_days", {}).get("revenue_fmt", "€0,00")
    ga4_sessions_7d = ga4["windows"].get("last_7_days", {}).get("sessions_fmt", "0")
    gsc_clicks_28d = gsc["windows"].get("last_28_days", {}).get("clicks_fmt", "0")
    return [
        ("Paid spend 7d", ads_spend_7d),
        ("Shopify revenue 28d", shop_rev_28d),
        ("GA4 sessions 7d", ga4_sessions_7d),
        ("GSC clicks 28d", gsc_clicks_28d),
    ]


def source_table(health):
    return ''.join(f'<tr><td>{row["name"]}</td><td><span class="mini-status mini-{row["status"]}">{row["status"]}</span></td><td>{row["detail"]}</td></tr>' for row in health.get("sources", []))


def signal_cards(signals):
    blocks = []
    for signal in signals:
        blocks.append(f'<div class="signal-card signal-{signal["tone"]}"><div class="signal-title">{signal["title"]}</div><div class="signal-detail">{signal["detail"]}</div></div>')
    return ''.join(blocks)


def main():
    meta = load("meta.json")
    ads = load("ads.json")
    gsc = load("gsc.json")
    ga4 = load("ga4.json")
    shopify = load("shopify.json")
    health = load("health.json")

    built = datetime.now().strftime("%Y-%m-%d %H:%M")
    signals = build_signals(ads, gsc, ga4, shopify)
    exec_cards = executive_cards(ads, gsc, ga4, shopify)

    html = f'''<!doctype html>
<html lang="nl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Econtrol Room — EcoHandel</title>
  <style>
    :root{{--bg:#06111d;--bg2:#0b1726;--panel:#0f2236;--panel2:#13304c;--line:#21415c;--text:#e8f0f7;--muted:#8ea7be;--green:#22c55e;--amber:#f59e0b;--red:#ef4444;--blue:#38bdf8;--cyan:#22d3ee;--purple:#8b5cf6;}}
    *{{box-sizing:border-box}} body{{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,sans-serif;background:radial-gradient(circle at top right,#153755 0,#06111d 45%);color:var(--text)}}
    .wrap{{max-width:1680px;margin:0 auto;padding:28px}}
    header{{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;padding:4px 0 24px;border-bottom:1px solid var(--line)}}
    .brand-kicker{{display:inline-flex;align-items:center;gap:10px;padding:8px 14px;border-radius:999px;border:1px solid rgba(34,211,238,.22);background:rgba(34,211,238,.08);color:var(--cyan);text-transform:uppercase;font-size:12px;font-weight:800;letter-spacing:.08em}}
    h1{{margin:10px 0 8px;font-size:48px;line-height:1;letter-spacing:-.04em}} .subhead{{color:var(--muted);max-width:800px;line-height:1.6}} .timestamp{{text-align:right;color:var(--muted);font-size:14px;line-height:1.6}}
    .hero{{display:grid;grid-template-columns:1.6fr .9fr;gap:18px;margin-top:22px}}
    .hero-card,.panel{{background:linear-gradient(180deg,var(--panel) 0,var(--panel2) 100%);border:1px solid var(--line);border-radius:24px;box-shadow:0 20px 70px rgba(0,0,0,.28)}}
    .hero-card{{padding:24px}}
    .hero-title{{font-size:28px;font-weight:900;letter-spacing:-.03em;margin:0 0 8px}}
    .hero-copy{{color:var(--muted);line-height:1.7;max-width:780px}}
    .hero-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:20px}}
    .hero-metric{{padding:18px;border-radius:18px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.05)}} .hero-metric .label{{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}} .hero-metric .value{{font-size:28px;font-weight:900;margin-top:7px}}
    .signal-stack{{display:grid;gap:12px;margin-top:18px}} .signal-card{{padding:16px 18px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:rgba(0,0,0,.16)}} .signal-title{{font-weight:800;font-size:15px;margin-bottom:5px}} .signal-detail{{color:var(--muted);line-height:1.6;font-size:14px}} .signal-good{{border-color:rgba(34,197,94,.24);background:rgba(34,197,94,.09)}} .signal-warn{{border-color:rgba(245,158,11,.24);background:rgba(245,158,11,.09)}} .signal-neutral{{border-color:rgba(56,189,248,.24);background:rgba(56,189,248,.08)}}
    .grid{{display:grid;grid-template-columns:repeat(12,1fr);gap:18px;margin-top:18px}} .span-4{{grid-column:span 4}} .span-6{{grid-column:span 6}} .span-8{{grid-column:span 8}} .span-12{{grid-column:span 12}}
    .panel{{padding:20px 20px 18px}} .panel-head{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:16px}} .eyebrow{{font-size:12px;color:var(--cyan);text-transform:uppercase;letter-spacing:.08em;font-weight:800}} h2{{margin:4px 0 0;font-size:24px;letter-spacing:-.03em}}
    .status{{padding:8px 12px;border-radius:999px;font-size:12px;font-weight:900;text-transform:uppercase;letter-spacing:.06em}} .status-live{{background:rgba(34,197,94,.12);color:var(--green);border:1px solid rgba(34,197,94,.25)}} .status-seed{{background:rgba(34,211,238,.12);color:var(--cyan);border:1px solid rgba(34,211,238,.25)}} .status-stub,.status-partial{{background:rgba(245,158,11,.12);color:#fbbf24;border:1px solid rgba(245,158,11,.25)}}
    .kpi-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}} .kpi-card{{padding:16px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.02)}} .kpi-label{{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}} .kpi-value{{font-size:22px;font-weight:900;margin-top:8px}} .tone-good .kpi-value{{color:var(--green)}} .tone-warn .kpi-value{{color:#fbbf24}} .tone-accent .kpi-value{{color:var(--cyan)}}
    .detail-grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px}} .detail-box{{padding:16px;border-radius:18px;background:rgba(0,0,0,.15);border:1px solid rgba(255,255,255,.05)}} .detail-box h3{{margin:0 0 10px;font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}}
    .stack{{margin:0;padding-left:18px;display:grid;gap:10px}} .stack li{{color:var(--text)}} .sub{{color:var(--muted);font-size:14px;margin-top:4px;line-height:1.55}} .chip{{display:inline-block;margin-left:8px;padding:3px 8px;border-radius:999px;background:rgba(56,189,248,.12);color:var(--cyan);font-size:11px;border:1px solid rgba(56,189,248,.2)}}
    .mini-table{{width:100%;border-collapse:collapse}} .mini-table th,.mini-table td{{padding:10px 8px;border-top:1px solid var(--line);text-align:left}} .mini-table th{{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}} .mini-table td{{font-size:14px}}
    .source-table{{width:100%;border-collapse:collapse}} .source-table th,.source-table td{{padding:12px 10px;border-top:1px solid var(--line);text-align:left}} .source-table th{{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em}}
    .mini-status{{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.06em}} .mini-live{{background:rgba(34,197,94,.12);color:var(--green)}} .mini-partial{{background:rgba(245,158,11,.12);color:#fbbf24}}
    .sanity-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}} .sanity-card{{padding:18px;border-radius:18px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06)}} .sanity-label{{font-size:11px;text-transform:uppercase;color:var(--muted);letter-spacing:.08em}} .sanity-value{{font-size:30px;font-weight:900;margin-top:8px}} .sanity-note{{margin-top:8px;color:var(--muted);line-height:1.55;font-size:14px}}
    .empty{{color:var(--muted)}} .stamp{{margin-top:14px;color:var(--muted);font-size:12px}} .footer{{margin-top:18px;color:var(--muted);font-size:13px;line-height:1.7}}
    @media (max-width:1180px){{.hero,.grid,.detail-grid,.kpi-grid,.hero-grid,.sanity-grid{{grid-template-columns:1fr}} .span-4,.span-6,.span-8,.span-12{{grid-column:span 1}} .timestamp{{text-align:left}} header{{align-items:flex-start;flex-direction:column}} }}
  </style>
</head>
<body>
  <div class="wrap">
    <header>
      <div>
        <div class="brand-kicker">Jean Clawd presents • Econtrol Room</div>
        <h1>Econtrol Room</h1>
        <div class="subhead">De commerciële cockpit van EcoHandel. Geen los dashboard meer, maar één plek waar paid, organic, analytics en Shopify elkaar controleren — zodat we sneller kunnen sturen op groei, winst en lekken.</div>
      </div>
      <div class="timestamp">Built {built}<br>Data mode: {meta.get("mode")}<br>All core sources: live</div>
    </header>

    <section class="hero">
      <div class="hero-card">
        <div class="eyebrow">Executive layer</div>
        <div class="hero-title">Alles wat ertoe doet, boven water</div>
        <div class="hero-copy">Dit is nu de vaste basis voor EcoHandel en straks de blauwdruk voor andere bedrijven. De bedoeling is simpel: binnen 10 seconden zien waar geld weglekt, waar groei zit, en welke databron een reality check nodig heeft.</div>
        <div class="hero-grid">
          {''.join(f'<div class="hero-metric"><div class="label">{label}</div><div class="value">{value}</div></div>' for label, value in exec_cards)}
        </div>
      </div>
      <div class="hero-card">
        <div class="eyebrow">Signals that matter</div>
        <div class="signal-stack">{signal_cards(signals)}</div>
      </div>
    </section>

    <div class="grid">
      <section class="panel span-12">
        <div class="panel-head">
          <div>
            <div class="eyebrow">Business sanity checks</div>
            <h2>Cross-checks tussen kanalen</h2>
          </div>
        </div>
        <div class="sanity-grid">
          <div class="sanity-card">
            <div class="sanity-label">Ads vs Shopify</div>
            <div class="sanity-value">{ads['windows']['last_7_days']['cost_eur']} → {shopify['windows']['last_28_days']['revenue_fmt']}</div>
            <div class="sanity-note">Ads-spend is nu live zichtbaar, maar conversion value in Ads loopt nog achter. Shopify is daarom de commerciële waarheid voor nu.</div>
          </div>
          <div class="sanity-card">
            <div class="sanity-label">GA4 vs Shopify revenue</div>
            <div class="sanity-value">{ga4['windows']['last_28_days']['revenue_fmt']} vs {shopify['windows']['last_28_days']['revenue_fmt']}</div>
            <div class="sanity-note">Als deze twee niet matchen, weet je meteen dat e-commerce revenue tracking of attributie nog niet goed zit.</div>
          </div>
          <div class="sanity-card">
            <div class="sanity-label">Organic traction</div>
            <div class="sanity-value">{gsc['windows']['last_28_days']['clicks_fmt']} clicks</div>
            <div class="sanity-note">Search Console blijft de bron voor vraag uit de markt. Domain property is vanaf nu de leidende GSC-bron.</div>
          </div>
        </div>
      </section>

      {section("Google Ads", "Revenue engine", ads, f'<div class="detail-box"><h3>KPI windows</h3>{windows_table(ads.get("windows", {}), "ads")}</div><div class="detail-box"><h3>Campaign pressure</h3>{list_items(ads.get("campaigns", []))}</div>')}
      {section("Google Search Console", "Demand capture", gsc, f'<div class="detail-box"><h3>KPI windows</h3>{windows_table(gsc.get("windows", {}), "gsc")}</div><div class="detail-box"><h3>Top opportunities</h3>{list_items(gsc.get("opportunities", []))}</div>')}
      {section("GA4", "Traffic quality", ga4, f'<div class="detail-box"><h3>KPI windows</h3>{windows_table(ga4.get("windows", {}), "ga4")}</div><div class="detail-box"><h3>Analytics notes</h3>{list_items(ga4.get("notes", []))}</div>')}
      {section("Shopify", "Commercial truth", shopify, f'<div class="detail-box"><h3>KPI windows</h3>{windows_table(shopify.get("windows", {}), "shopify")}</div><div class="detail-box"><h3>Top products</h3>{list_items(shopify.get("top_products", []))}</div>')}

      <section class="panel span-8">
        <div class="panel-head">
          <div>
            <div class="eyebrow">Search winners</div>
            <h2>Pagina’s en queries die nu tractie tonen</h2>
          </div>
        </div>
        <div class="detail-grid">
          <div class="detail-box"><h3>Top queries</h3>{list_items(gsc.get("opportunities", []))}</div>
          <div class="detail-box"><h3>Top pages</h3>{list_items(gsc.get("top_pages", []))}</div>
        </div>
      </section>

      <section class="panel span-4">
        <div class="panel-head">
          <div>
            <div class="eyebrow">System health</div>
            <h2>Bronnen & betrouwbaarheid</h2>
          </div>
        </div>
        <table class="source-table">
          <thead><tr><th>Source</th><th>Status</th><th>Detail</th></tr></thead>
          <tbody>{source_table(health)}</tbody>
        </table>
        <div class="footer">Project: {meta.get("project")} · Company: {meta.get("company")}<br>Generated: {meta.get("generated_at")}<br>GSC source: {gsc.get("property")}</div>
      </section>
    </div>
  </div>
</body>
</html>'''

    OUT.write_text(html)
    print(json.dumps({"ok": True, "output": str(OUT)}))


if __name__ == "__main__":
    main()
