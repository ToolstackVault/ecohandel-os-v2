#!/usr/bin/env python3
import json
import os
import subprocess
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
DATA_DIR = ROOT / "dashboard" / "data"
SEED_PATH = ROOT / "config" / "seed_data.json"
ADS_VENV_PY = WORKSPACE / ".venv-googleads311" / "bin" / "python"
ADS_CONFIG = WORKSPACE / "secrets" / "google-ads.yaml"
GOOGLE_SERVICE_ACCOUNT = WORKSPACE / ".env" / "google_service_account.json"
APIS_ENV = WORKSPACE / ".env" / "apis.env"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_seed():
    return json.loads(SEED_PATH.read_text())


def write_json(name: str, payload: dict):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / name).write_text(json.dumps(payload, indent=2, ensure_ascii=False))


def load_env_file(path: Path) -> dict:
    env = {}
    if not path.exists():
        return env
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip().strip('"').strip("'")
    return env


def euro(value: float | int | None, decimals: int = 2) -> str:
    if value is None:
        return "-"
    fmt = f"{value:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"€{fmt}"


def compact_number(value: float | int | None, decimals: int = 0) -> str:
    if value is None:
        return "-"
    if decimals:
        return f"{value:,.{decimals}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{int(round(value)):,}".replace(",", ".")


def pct(value: float | int | None, decimals: int = 1) -> str:
    if value is None:
        return "-"
    return f"{value:.{decimals}f}%".replace(".", ",")


def tone_from_ratio(value: float | None, good_at: float, warn_at: float) -> str:
    if value is None:
        return "warn"
    if value >= good_at:
        return "good"
    if value >= warn_at:
        return "neutral"
    return "warn"


def build_meta(seed: dict) -> dict:
    return {
        "generated_at": now_iso(),
        "project": seed["meta"]["brand"],
        "company": seed["meta"]["company"],
        "mode": "local-read-only-live-when-available"
    }


def build_windows_list(windows: dict, primary_metric: str, secondary_metric: str | None = None):
    rows = []
    for key in ["today", "yesterday", "last_7_days", "last_28_days"]:
        row = windows.get(key)
        if not row:
            continue
        detail = primary_metric.format(**row)
        if secondary_metric:
            detail += " · " + secondary_metric.format(**row)
        rows.append({"type": row["label"], "detail": detail})
    return rows


def google_credentials(scopes: list[str]):
    from google.oauth2 import service_account
    return service_account.Credentials.from_service_account_file(str(GOOGLE_SERVICE_ACCOUNT), scopes=scopes)


def fetch_google_ads(seed_ads: dict, fetched_at: str) -> tuple[dict, dict]:
    fallback = {**seed_ads, "fetched_at": fetched_at, "source": "seed+audit"}
    if not ADS_VENV_PY.exists() or not ADS_CONFIG.exists():
        fallback["notes"] = list(fallback.get("notes", [])) + ["Live Ads adapter kon niet starten: venv of config ontbreekt."]
        return fallback, {"name": "Google Ads", "status": "seed-ready", "detail": "Credentials known; live adapter blocked locally"}

    script = r'''
import json
from datetime import date, timedelta
from google.ads.googleads.client import GoogleAdsClient

client = GoogleAdsClient.load_from_storage("'''+str(ADS_CONFIG)+r'''")
customer_id = "5921907188"
service = client.get_service("GoogleAdsService")

windows = {
    "today": (date.today().isoformat(), date.today().isoformat(), "Today"),
    "yesterday": ((date.today()-timedelta(days=1)).isoformat(), (date.today()-timedelta(days=1)).isoformat(), "Yesterday"),
    "last_7_days": ((date.today()-timedelta(days=6)).isoformat(), date.today().isoformat(), "Last 7 days"),
    "last_28_days": ((date.today()-timedelta(days=27)).isoformat(), date.today().isoformat(), "Last 28 days"),
}

result = {"windows": {}, "campaigns": []}
for key, (start_date, end_date, label) in windows.items():
    query = f"""
    SELECT
      metrics.impressions,
      metrics.clicks,
      metrics.cost_micros,
      metrics.conversions,
      metrics.conversions_value
    FROM customer
    WHERE segments.date BETWEEN '{start_date}' AND '{end_date}'
    """
    rows = list(service.search(customer_id=customer_id, query=query))
    row = rows[0] if rows else None
    result["windows"][key] = {
        "label": label,
        "impressions": row.metrics.impressions if row else 0,
        "clicks": row.metrics.clicks if row else 0,
        "cost": row.metrics.cost_micros / 1_000_000 if row else 0,
        "conversions": row.metrics.conversions if row else 0,
        "conversion_value": row.metrics.conversions_value if row else 0,
    }

campaign_query = f"""
SELECT
  campaign.id,
  campaign.name,
  campaign.status,
  campaign.advertising_channel_type,
  metrics.impressions,
  metrics.clicks,
  metrics.cost_micros,
  metrics.conversions,
  metrics.conversions_value
FROM campaign
WHERE segments.date BETWEEN '{windows['last_7_days'][0]}' AND '{windows['last_7_days'][1]}'
ORDER BY metrics.cost_micros DESC
LIMIT 5
"""
for row in service.search(customer_id=customer_id, query=campaign_query):
    result["campaigns"].append({
        "id": row.campaign.id,
        "name": row.campaign.name,
        "status": row.campaign.status.name,
        "channel": row.campaign.advertising_channel_type.name,
        "impressions": row.metrics.impressions,
        "clicks": row.metrics.clicks,
        "cost": row.metrics.cost_micros / 1_000_000,
        "conversions": row.metrics.conversions,
        "conversion_value": row.metrics.conversions_value,
    })

print(json.dumps(result))
'''
    try:
        proc = subprocess.run([str(ADS_VENV_PY), "-c", script], capture_output=True, text=True, cwd=str(WORKSPACE), timeout=90)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or proc.stdout.strip() or "Unknown Google Ads error")
        raw = json.loads(proc.stdout)
        windows = raw.get("windows", {})
        today = windows.get("today", {})
        yesterday = windows.get("yesterday", {})
        last7 = windows.get("last_7_days", {})
        last28 = windows.get("last_28_days", {})
        roas7 = (last7.get("conversion_value", 0) / last7.get("cost", 1)) if last7.get("cost") else None
        ctr_today = (today.get("clicks", 0) / today.get("impressions", 1) * 100) if today.get("impressions") else None
        for row in windows.values():
            row["cost_eur"] = euro(row.get("cost", 0))
            row["value_eur"] = euro(row.get("conversion_value", 0))
            row["ctr"] = pct((row.get("clicks", 0) / row.get("impressions", 1) * 100) if row.get("impressions") else None)
            row["clicks"] = compact_number(row.get("clicks", 0))

        live = {
            "status": "live",
            "summary": {
                "window": "Today / Yesterday / 7d / 28d",
                "health": "live_read_ok"
            },
            "kpis": [
                {"label": "Spend today", "value": euro(today.get("cost", 0)), "tone": "neutral"},
                {"label": "Spend yesterday", "value": euro(yesterday.get("cost", 0)), "tone": "neutral"},
                {"label": "ROAS 7d", "value": f"{roas7:.2f}x" if roas7 is not None else "-", "tone": tone_from_ratio(roas7, 4.0, 2.0)},
                {"label": "Conv. value 28d", "value": euro(last28.get("conversion_value", 0)), "tone": "good" if last28.get("conversion_value", 0) > 0 else "warn"}
            ],
            "windows": windows,
            "notes": build_windows_list(
                windows,
                "Spend {cost_eur} · Value {value_eur}",
                "Clicks {clicks} · CTR {ctr}"
            ),
            "campaigns": [
                {
                    "name": row["name"],
                    "status": row["status"],
                    "focus": f"{row['channel']} · Spend {euro(row['cost'])} · Value {euro(row['conversion_value'])}",
                    "risk": "Needs value sanity check" if row.get("conversion_value", 0) <= 0 else None
                }
                for row in raw.get("campaigns", [])
            ],
            "fetched_at": fetched_at,
            "source": "google-ads-api"
        }
        return live, {"name": "Google Ads", "status": "live", "detail": "Google Ads API windows OK"}
    except Exception as exc:
        fallback["status"] = "partial"
        fallback["notes"] = list(fallback.get("notes", [])) + [f"Live Ads adapter faalde, seed fallback actief: {exc}"]
        fallback["source"] = "seed+ads-error"
        return fallback, {"name": "Google Ads", "status": "partial", "detail": "Seed fallback; live query failed"}


def gsc_query(service, site_url: str, start: date, end: date, dimensions=None, row_limit=5):
    body = {
        "startDate": start.isoformat(),
        "endDate": end.isoformat(),
        "dimensions": dimensions or [],
        "rowLimit": row_limit,
        "startRow": 0,
    }
    return service.searchanalytics().query(siteUrl=site_url, body=body).execute()


def fetch_gsc(seed_gsc: dict, fetched_at: str) -> tuple[dict, dict]:
    fallback = {**seed_gsc, "fetched_at": fetched_at, "source": "seed+audit"}
    if not GOOGLE_SERVICE_ACCOUNT.exists():
        fallback["opportunities"] = list(fallback.get("opportunities", [])) + [{"type": "Adapter", "detail": "Service account ontbreekt lokaal."}]
        return fallback, {"name": "GSC", "status": "seed-ready", "detail": "Service account missing locally"}
    try:
        from googleapiclient.discovery import build
        service = build("searchconsole", "v1", credentials=google_credentials(["https://www.googleapis.com/auth/webmasters.readonly"]), cache_discovery=False)
        preferred_site = "sc-domain:ecohandel.nl"
        fallback_site = "https://www.ecohandel.nl/"
        today = date.today()
        periods = {
            "today": (today, today, "Today"),
            "yesterday": (today - timedelta(days=1), today - timedelta(days=1), "Yesterday"),
            "last_7_days": (today - timedelta(days=6), today, "Last 7 days"),
            "last_28_days": (today - timedelta(days=27), today, "Last 28 days"),
        }

        def collect_for_site(site_url: str):
            windows_local = {}
            for key, (start, end, label) in periods.items():
                summary = gsc_query(service, site_url, start, end)
                windows_local[key] = {
                    "label": label,
                    "clicks": summary.get("clicks", 0),
                    "impressions": summary.get("impressions", 0),
                    "ctr": (summary.get("ctr", 0) * 100) if summary.get("ctr") is not None else None,
                    "position": summary.get("position"),
                }
            queries_local = gsc_query(service, site_url, today - timedelta(days=27), today, ["query"], 5).get("rows", [])
            pages_local = gsc_query(service, site_url, today - timedelta(days=27), today, ["page"], 5).get("rows", [])
            return windows_local, queries_local, pages_local

        windows, queries, pages = collect_for_site(preferred_site)
        site_url = preferred_site
        if windows.get("last_28_days", {}).get("clicks", 0) == 0 and not queries and not pages:
            windows, queries, pages = collect_for_site(fallback_site)
            site_url = fallback_site

        if windows.get("last_28_days", {}).get("clicks", 0) == 0 and pages:
            total_clicks = sum(row.get("clicks", 0) for row in pages)
            total_impressions = sum(row.get("impressions", 0) for row in pages)
            weighted_position_num = sum((row.get("position", 0) or 0) * row.get("impressions", 0) for row in pages)
            weighted_position = (weighted_position_num / total_impressions) if total_impressions else None
            windows["last_28_days"]["clicks"] = total_clicks
            windows["last_28_days"]["impressions"] = total_impressions
            windows["last_28_days"]["ctr"] = (total_clicks / total_impressions * 100) if total_impressions else None
            windows["last_28_days"]["position"] = weighted_position

        if windows.get("last_7_days", {}).get("clicks", 0) == 0 and queries:
            total_clicks = sum(row.get("clicks", 0) for row in queries)
            total_impressions = sum(row.get("impressions", 0) for row in queries)
            weighted_position_num = sum((row.get("position", 0) or 0) * row.get("impressions", 0) for row in queries)
            weighted_position = (weighted_position_num / total_impressions) if total_impressions else None
            windows["last_7_days"]["clicks"] = total_clicks
            windows["last_7_days"]["impressions"] = total_impressions
            windows["last_7_days"]["ctr"] = (total_clicks / total_impressions * 100) if total_impressions else None
            windows["last_7_days"]["position"] = weighted_position

        for row in windows.values():
            row["clicks_fmt"] = compact_number(row.get("clicks", 0))
            row["impressions_fmt"] = compact_number(row.get("impressions", 0))
            row["ctr_fmt"] = pct(row.get("ctr"))
            row["position_fmt"] = f"{row['position']:.1f}" if row.get("position") is not None else "-"

        last28 = windows["last_28_days"]
        opportunities = []
        for row in queries[:3]:
            q = row.get("keys", [""])[0]
            opportunities.append({
                "type": q or "Query",
                "detail": f"{compact_number(row.get('impressions', 0))} impressions · CTR {pct(row.get('ctr', 0) * 100)} · Pos {row.get('position', 0):.1f}"
            })

        live = {
            "status": "live",
            "property": site_url,
            "health": "url_prefix_live",
            "kpis": [
                {"label": "Clicks today", "value": windows['today']['clicks_fmt'], "tone": "good" if windows['today'].get('clicks', 0) > 0 else "warn"},
                {"label": "Clicks yesterday", "value": windows['yesterday']['clicks_fmt'], "tone": "neutral"},
                {"label": "Clicks 7d", "value": windows['last_7_days']['clicks_fmt'], "tone": "good" if windows['last_7_days'].get('clicks', 0) > 0 else "warn"},
                {"label": "CTR 28d", "value": last28['ctr_fmt'], "tone": tone_from_ratio(last28.get('ctr'), 3.0, 1.0)}
            ],
            "windows": windows,
            "opportunities": opportunities,
            "top_pages": [
                {
                    "type": row.get("keys", [""])[0].replace("https://www.ecohandel.nl", "") or "/",
                    "detail": f"{compact_number(row.get('clicks', 0))} clicks · {compact_number(row.get('impressions', 0))} impressions · CTR {pct(row.get('ctr', 0) * 100)}"
                }
                for row in pages[:5]
            ],
            "fetched_at": fetched_at,
            "source": "google-search-console"
        }
        return live, {"name": "GSC", "status": "live", "detail": "Search Console API windows OK"}
    except Exception as exc:
        fallback["status"] = "partial"
        fallback["opportunities"] = list(fallback.get("opportunities", [])) + [{"type": "Adapter fallback", "detail": str(exc)}]
        fallback["source"] = "seed+gsc-error"
        return fallback, {"name": "GSC", "status": "partial", "detail": "Seed fallback; live query failed"}


def fetch_ga4(seed_ga4: dict, fetched_at: str) -> tuple[dict, dict]:
    fallback = {**seed_ga4, "fetched_at": fetched_at, "source": "seed+audit"}
    env = load_env_file(APIS_ENV)
    property_id = os.environ.get("GA4_PROPERTY_ID") or env.get("GA4_PROPERTY_ID")
    if not property_id:
        fallback["status"] = "partial"
        fallback["notes"] = list(fallback.get("notes", [])) + ["GA4 live adapter wacht nog op property ID voor Data API of Admin API enablement."]
        fallback["source"] = "seed+ga4-pending"
        return fallback, {"name": "GA4", "status": "partial", "detail": "Property ID missing; live Analytics still blocked"}
    try:
        from googleapiclient.discovery import build
        service = build("analyticsdata", "v1beta", credentials=google_credentials(["https://www.googleapis.com/auth/analytics.readonly"]), cache_discovery=False)
        today = date.today()
        periods = {
            "today": (today, today, "Today"),
            "yesterday": (today - timedelta(days=1), today - timedelta(days=1), "Yesterday"),
            "last_7_days": (today - timedelta(days=6), today, "Last 7 days"),
            "last_28_days": (today - timedelta(days=27), today, "Last 28 days"),
        }
        windows = {}
        for key, (start, end, label) in periods.items():
            body = {
                "dateRanges": [{"startDate": start.isoformat(), "endDate": end.isoformat()}],
                "metrics": [{"name": "sessions"}, {"name": "activeUsers"}, {"name": "totalRevenue"}],
            }
            response = service.properties().runReport(property=f"properties/{property_id}", body=body).execute()
            row = response.get("rows", [{}])[0]
            vals = row.get("metricValues", [])
            windows[key] = {
                "label": label,
                "sessions": float(vals[0].get("value", 0)) if len(vals) > 0 else 0,
                "active_users": float(vals[1].get("value", 0)) if len(vals) > 1 else 0,
                "revenue": float(vals[2].get("value", 0)) if len(vals) > 2 else 0,
            }
            windows[key]["sessions_fmt"] = compact_number(windows[key]["sessions"])
            windows[key]["active_users_fmt"] = compact_number(windows[key]["active_users"])
            windows[key]["revenue_fmt"] = euro(windows[key]["revenue"])

        live = {
            "status": "live",
            "measurement_id": seed_ga4.get("measurement_id"),
            "property_id": property_id,
            "health": "ga4-data-api-live",
            "kpis": [
                {"label": "Sessions today", "value": windows['today']['sessions_fmt'], "tone": "good" if windows['today']['sessions'] > 0 else "warn"},
                {"label": "Sessions yesterday", "value": windows['yesterday']['sessions_fmt'], "tone": "neutral"},
                {"label": "Sessions 7d", "value": windows['last_7_days']['sessions_fmt'], "tone": "good" if windows['last_7_days']['sessions'] > 0 else "warn"},
                {"label": "Revenue 28d", "value": windows['last_28_days']['revenue_fmt'], "tone": "good" if windows['last_28_days']['revenue'] > 0 else "warn"}
            ],
            "windows": windows,
            "notes": build_windows_list(windows, "Sessions {sessions_fmt} · Users {active_users_fmt}", "Revenue {revenue_fmt}"),
            "fetched_at": fetched_at,
            "source": "ga4-data-api"
        }
        return live, {"name": "GA4", "status": "live", "detail": "GA4 Data API windows OK"}
    except Exception as exc:
        fallback["status"] = "partial"
        fallback["notes"] = list(fallback.get("notes", [])) + [f"GA4 property ID gezet, maar live fetch faalde: {exc}"]
        fallback["source"] = "seed+ga4-error"
        return fallback, {"name": "GA4", "status": "partial", "detail": "Property set, but Analytics query failed"}


def shopify_request(url: str, token: str) -> dict:
    req = urllib.request.Request(url, headers={
        "X-Shopify-Access-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    with urllib.request.urlopen(req, timeout=45) as resp:
        return json.loads(resp.read().decode("utf-8"))


def aggregate_shopify_orders(orders: list[dict]) -> dict:
    revenue = 0.0
    order_count = 0
    product_counter = Counter()
    product_revenue = defaultdict(float)
    for order in orders:
        try:
            revenue += float(order.get("current_total_price") or order.get("total_price") or 0)
        except Exception:
            pass
        order_count += 1
        for item in order.get("line_items", []):
            title = item.get("title") or f"Product {item.get('product_id') or ''}".strip()
            qty = int(item.get("quantity") or 0)
            product_counter[title] += qty
            try:
                product_revenue[title] += float(item.get("price") or 0) * qty
            except Exception:
                pass
    aov = revenue / order_count if order_count else 0
    return {
        "revenue": revenue,
        "orders": order_count,
        "aov": aov,
        "product_counter": product_counter,
        "product_revenue": product_revenue,
    }


def fetch_shopify(seed_shopify: dict, fetched_at: str) -> tuple[dict, dict]:
    fallback = {**seed_shopify, "fetched_at": fetched_at, "source": "stub"}
    env = load_env_file(APIS_ENV)
    configured_store_url = os.environ.get("SHOPIFY_STORE_URL") or env.get("SHOPIFY_STORE_URL") or "https://n6f6ja-qr.myshopify.com"
    if not configured_store_url.startswith("http://") and not configured_store_url.startswith("https://"):
        configured_store_url = "https://" + configured_store_url
    api_version = os.environ.get("SHOPIFY_API_VERSION") or env.get("SHOPIFY_API_VERSION") or "2026-01"
    token = os.environ.get("SHOPIFY_ADMIN_TOKEN") or env.get("SHOPIFY_ADMIN_TOKEN")
    if not token:
        fallback["notes"] = list(fallback.get("notes", [])) + ["Shopify admin token ontbreekt in .env/apis.env."]
        return fallback, {"name": "Shopify", "status": "stub", "detail": "Token missing; module still stub"}
    try:
        now = datetime.now(timezone.utc)
        created_at_min = (now - timedelta(days=30)).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        store_candidates = [configured_store_url, "https://n6f6ja-qr.myshopify.com"]
        orders = None
        store_url = configured_store_url
        last_error = None
        for candidate in store_candidates:
            if not candidate:
                continue
            try:
                base = candidate.rstrip("/") + f"/admin/api/{api_version}"
                orders_url = base + "/orders.json?status=any&limit=250&created_at_min=" + urllib.parse.quote(created_at_min)
                orders = shopify_request(orders_url, token).get("orders", [])
                store_url = candidate
                break
            except Exception as exc:
                last_error = exc
                continue
        if orders is None:
            raise last_error or RuntimeError("Shopify request failed")

        start_today = now.date()
        start_yesterday = now.date() - timedelta(days=1)
        order_windows = {"today": [], "yesterday": [], "last_7_days": [], "last_28_days": []}
        for order in orders:
            created_raw = order.get("created_at")
            try:
                created_dt = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
            except Exception:
                continue
            created_date = created_dt.astimezone(timezone.utc).date()
            if created_date == start_today:
                order_windows["today"].append(order)
            if created_date == start_yesterday:
                order_windows["yesterday"].append(order)
            if created_date >= now.date() - timedelta(days=6):
                order_windows["last_7_days"].append(order)
            if created_date >= now.date() - timedelta(days=27):
                order_windows["last_28_days"].append(order)

        windows = {
            "today": {"label": "Today", **aggregate_shopify_orders(order_windows['today'])},
            "yesterday": {"label": "Yesterday", **aggregate_shopify_orders(order_windows['yesterday'])},
            "last_7_days": {"label": "Last 7 days", **aggregate_shopify_orders(order_windows['last_7_days'])},
            "last_28_days": {"label": "Last 28 days", **aggregate_shopify_orders(order_windows['last_28_days'])},
        }
        for row in windows.values():
            row["revenue_fmt"] = euro(row.get("revenue", 0))
            row["orders_fmt"] = compact_number(row.get("orders", 0))
            row["aov_fmt"] = euro(row.get("aov", 0)) if row.get("orders", 0) else "-"

        top_counter = windows["last_28_days"]["product_counter"]
        top_revenue = windows["last_28_days"]["product_revenue"]
        tops = [
            {"name": title, "detail": f"{qty} stuks · omzet {euro(top_revenue.get(title, 0))}"}
            for title, qty in top_counter.most_common(5)
        ]

        live = {
            "status": "live",
            "store": store_url.replace("https://", ""),
            "kpis": [
                {"label": "Revenue today", "value": windows['today']['revenue_fmt'], "tone": "good" if windows['today']['revenue'] > 0 else "warn"},
                {"label": "Revenue yesterday", "value": windows['yesterday']['revenue_fmt'], "tone": "neutral"},
                {"label": "Orders 7d", "value": windows['last_7_days']['orders_fmt'], "tone": "good" if windows['last_7_days']['orders'] > 0 else "warn"},
                {"label": "Revenue 28d", "value": windows['last_28_days']['revenue_fmt'], "tone": "good" if windows['last_28_days']['revenue'] > 0 else "warn"}
            ],
            "windows": windows,
            "notes": build_windows_list(windows, "Revenue {revenue_fmt} · Orders {orders_fmt}", "AOV {aov_fmt}"),
            "top_products": tops,
            "fetched_at": fetched_at,
            "source": "shopify-admin-api"
        }
        return live, {"name": "Shopify", "status": "live", "detail": "Shopify Admin API windows OK"}
    except Exception as exc:
        fallback["status"] = "partial"
        fallback["notes"] = list(fallback.get("notes", [])) + [f"Shopify live adapter faalde, stub fallback actief: {exc}"]
        fallback["source"] = "stub+shopify-error"
        return fallback, {"name": "Shopify", "status": "partial", "detail": "Stub fallback; Shopify query failed"}


def fetch_wefact(fetched_at: str) -> tuple[dict, dict]:
    env = load_env_file(APIS_ENV)
    api_key = env.get("WEFACT_API_KEY") or os.environ.get("WEFACT_API_KEY")
    base_url = (env.get("WEFACT_BASE_URL") or os.environ.get("WEFACT_BASE_URL") or "https://api.mijnwefact.nl/v2").rstrip('/') + '/'
    fallback = {
        "status": "missing",
        "summary": {"window": "Today / Yesterday / 7d / 28d", "health": "config_missing"},
        "kpis": [],
        "windows": {},
        "recent_invoices": [],
        "recent_quotes": [],
        "notes": ["Wefact config ontbreekt of is nog niet gekoppeld."],
        "fetched_at": fetched_at,
        "source": "wefact-missing"
    }
    if not api_key:
        return fallback, {"name": "Wefact", "status": "missing", "detail": "API key missing"}

    def post_json(payload: dict) -> dict:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(base_url, data=data, headers={"Content-Type": "application/json", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def to_items(raw: dict, key: str) -> list[dict]:
        items = raw.get(key, [])
        if isinstance(items, dict):
            return list(items.values())
        return items if isinstance(items, list) else []

    try:
        invoices_raw = post_json({"api_key": api_key, "controller": "invoice", "action": "list", "limit": 100})
        quotes_raw = post_json({"api_key": api_key, "controller": "pricequote", "action": "list", "limit": 100})
        debtors_raw = post_json({"api_key": api_key, "controller": "debtor", "action": "list", "limit": 100})
        invoices = to_items(invoices_raw, "invoices")
        quotes = to_items(quotes_raw, "pricequotes")
        debtors = to_items(debtors_raw, "debtors")
        now = datetime.now(timezone.utc)

        def parse_date(value: str | None):
            if not value:
                return None
            for fmt in ["%Y-%m-%d", "%Y-%m-%d %H:%M:%S"]:
                try:
                    dt = datetime.strptime(value, fmt)
                    return dt.replace(tzinfo=timezone.utc)
                except Exception:
                    continue
            return None

        def as_float(value):
            try:
                return float(value or 0)
            except Exception:
                return 0.0

        invoice_windows = {"today": [], "yesterday": [], "last_7_days": [], "last_28_days": []}
        quote_windows = {"today": [], "yesterday": [], "last_7_days": [], "last_28_days": []}
        for item in invoices:
            dt = parse_date(item.get("Date"))
            if not dt:
                continue
            d = dt.date()
            if d == now.date():
                invoice_windows["today"].append(item)
            if d == now.date() - timedelta(days=1):
                invoice_windows["yesterday"].append(item)
            if d >= now.date() - timedelta(days=6):
                invoice_windows["last_7_days"].append(item)
            if d >= now.date() - timedelta(days=27):
                invoice_windows["last_28_days"].append(item)
        for item in quotes:
            dt = parse_date(item.get("Date"))
            if not dt:
                continue
            d = dt.date()
            if d == now.date():
                quote_windows["today"].append(item)
            if d == now.date() - timedelta(days=1):
                quote_windows["yesterday"].append(item)
            if d >= now.date() - timedelta(days=6):
                quote_windows["last_7_days"].append(item)
            if d >= now.date() - timedelta(days=27):
                quote_windows["last_28_days"].append(item)

        windows = {}
        for key, label in [("today", "Today"), ("yesterday", "Yesterday"), ("last_7_days", "Last 7 days"), ("last_28_days", "Last 28 days")]:
            inv = invoice_windows[key]
            quo = quote_windows[key]
            invoice_total = sum(as_float(i.get("AmountIncl")) for i in inv)
            invoice_outstanding = sum(max(0.0, as_float(i.get("AmountOutstanding"))) for i in inv)
            quote_total = sum(as_float(i.get("AmountIncl")) for i in quo)
            windows[key] = {
                "label": label,
                "invoice_count": len(inv),
                "quote_count": len(quo),
                "invoice_total": invoice_total,
                "invoice_total_fmt": euro(invoice_total),
                "quote_total": quote_total,
                "quote_total_fmt": euro(quote_total),
                "open_outstanding": invoice_outstanding,
                "open_outstanding_fmt": euro(invoice_outstanding),
                "invoice_count_fmt": compact_number(len(inv)),
                "quote_count_fmt": compact_number(len(quo)),
            }

        total_open = sum(max(0.0, as_float(i.get("AmountOutstanding"))) for i in invoices)
        recent_invoices = [
            {
                "name": f"{i.get('InvoiceCode', '-') } · {i.get('CompanyName', '-')}",
                "detail": f"{i.get('Date', '-')} · {euro(as_float(i.get('AmountIncl')))} · open {euro(as_float(i.get('AmountOutstanding')))}"
            }
            for i in sorted(invoices, key=lambda x: x.get("Date", ""), reverse=True)[:5]
        ]
        recent_quotes = [
            {
                "name": f"{q.get('PriceQuoteCode', '-')} · {q.get('CompanyName', '-')}",
                "detail": f"{q.get('Date', '-')} · {euro(as_float(q.get('AmountIncl')))}"
            }
            for q in sorted(quotes, key=lambda x: x.get("Date", ""), reverse=True)[:5]
        ]
        live = {
            "status": "live",
            "summary": {"window": "Today / Yesterday / 7d / 28d", "health": "live_read_ok"},
            "kpis": [
                {"label": "Invoices 28d", "value": windows['last_28_days']['invoice_count_fmt'], "tone": "good" if windows['last_28_days']['invoice_count'] > 0 else "warn"},
                {"label": "Invoiced 28d", "value": windows['last_28_days']['invoice_total_fmt'], "tone": "good" if windows['last_28_days']['invoice_total'] > 0 else "warn"},
                {"label": "Quotes 28d", "value": windows['last_28_days']['quote_count_fmt'], "tone": "neutral"},
                {"label": "Openstaand", "value": euro(total_open), "tone": "warn" if total_open > 0 else "good"}
            ],
            "windows": windows,
            "notes": build_windows_list(windows, "Facturen {invoice_count_fmt} · Omzet {invoice_total_fmt}", "Offertes {quote_count_fmt} · Open {open_outstanding_fmt}"),
            "recent_invoices": recent_invoices,
            "recent_quotes": recent_quotes,
            "debtors_total": len(debtors),
            "fetched_at": fetched_at,
            "source": "wefact-api"
        }
        return live, {"name": "Wefact", "status": "live", "detail": f"{len(invoices)} invoices · {len(quotes)} quotes"}
    except Exception as exc:
        fallback["status"] = "partial"
        fallback["summary"]["health"] = "error"
        fallback["notes"] = [f"Wefact read-only adapter faalde: {exc}"]
        fallback["source"] = "wefact-error"
        return fallback, {"name": "Wefact", "status": "partial", "detail": f"Read-only failed: {exc}"}


def main():
    seed = load_seed()
    meta = build_meta(seed)
    fetched_at = meta["generated_at"]

    ads, ads_health = fetch_google_ads(seed["ads"], fetched_at)
    gsc, gsc_health = fetch_gsc(seed["gsc"], fetched_at)
    ga4, ga4_health = fetch_ga4(seed["ga4"], fetched_at)
    shopify, shopify_health = fetch_shopify(seed["shopify"], fetched_at)
    wefact, wefact_health = fetch_wefact(fetched_at)

    write_json("meta.json", meta)
    write_json("ads.json", ads)
    write_json("gsc.json", gsc)
    write_json("ga4.json", ga4)
    write_json("shopify.json", shopify)
    write_json("wefact.json", wefact)
    write_json("health.json", {
        "fetched_at": fetched_at,
        "sources": [ads_health, gsc_health, ga4_health, shopify_health, wefact_health]
    })
    print(json.dumps({"ok": True, "generated_at": fetched_at, "mode": meta["mode"]}))


if __name__ == "__main__":
    main()
