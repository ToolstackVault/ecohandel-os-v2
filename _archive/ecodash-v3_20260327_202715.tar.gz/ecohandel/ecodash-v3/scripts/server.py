#!/usr/bin/env python3
import json
import subprocess
import time
from pathlib import Path
from flask import Flask, jsonify, send_from_directory

ROOT = Path(__file__).resolve().parents[1]
DASHBOARD_DIR = ROOT / "dashboard"
DATA_DIR = DASHBOARD_DIR / "data"
STATUS_PATH = DATA_DIR / "refresh_status.json"

app = Flask(__name__)


def write_status(payload):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    STATUS_PATH.write_text(json.dumps({**payload, "ts": time.time()}, indent=2))


@app.route("/")
def index():
    return send_from_directory(str(DASHBOARD_DIR), "index.html")


@app.route("/status")
def status():
    if STATUS_PATH.exists():
        return jsonify(json.loads(STATUS_PATH.read_text()))
    return jsonify({"running": False, "ok": None, "message": "Ready"})


@app.route("/refresh", methods=["POST"])
def refresh():
    try:
        write_status({"running": True, "ok": None, "message": "Refreshing"})
        fetch = subprocess.run(["python3", str(ROOT / "scripts" / "fetch_all.py")], cwd=ROOT, capture_output=True, text=True)
        build = subprocess.run(["python3", str(ROOT / "scripts" / "build_dashboard.py")], cwd=ROOT, capture_output=True, text=True)
        ok = fetch.returncode == 0 and build.returncode == 0
        write_status({
            "running": False,
            "ok": ok,
            "message": "OK" if ok else "FAILED",
            "log_tail": (fetch.stdout + fetch.stderr + "\n" + build.stdout + build.stderr)[-2000:],
            "finished_at": time.time()
        })
        return jsonify({"ok": ok})
    except Exception as exc:
        write_status({"running": False, "ok": False, "message": str(exc)})
        return jsonify({"ok": False, "error": str(exc)}), 500


def main():
    if not STATUS_PATH.exists():
        write_status({"running": False, "ok": None, "message": "Ready"})
    app.run(host="127.0.0.1", port=8791, debug=False)


if __name__ == "__main__":
    main()
