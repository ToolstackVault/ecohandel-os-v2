# EcoDashV3

Lokale desktop-first control room voor EcoHandel.

## Prioriteit
1. Google Ads
2. GSC / GA4
3. Shopify omzet, orders, best sellers

## V1 architectuur
- `scripts/fetch_all.py` — read-only data collector met graceful degradation
- `scripts/build_dashboard.py` — bouwt `dashboard/index.html`
- `scripts/server.py` — lokale preview + refresh endpoints
- `dashboard/data/*.json` — snapshots / cache / seed data
- `docs/data-sources.md` — audit + blockers + next steps

## Start lokaal

```bash
cd /Users/ecohandel.nl/.openclaw/workspace/ecohandel/ecodash-v3
python3 scripts/fetch_all.py
python3 scripts/build_dashboard.py
open dashboard/index.html
```

Of met live lokale server:

```bash
python3 scripts/server.py
# open http://127.0.0.1:8791
```

## Refresh flow
- Default is read-only.
- Als credentials of tools ontbreken, schrijft de fetcher een nette status terug in JSON in plaats van hard te falen.
- Seed data is gebaseerd op bekende EcoHandel context zodat de shell direct bruikbaar is vannacht.

## Volgende slag
- Shopify omzet/orders read-only snapshot werkend maken via juiste Admin API toegang
- GA4 read-only koppelen zodra property ID bevestigd is
- Branding/logo netjes afwerken en control-room polish doen
