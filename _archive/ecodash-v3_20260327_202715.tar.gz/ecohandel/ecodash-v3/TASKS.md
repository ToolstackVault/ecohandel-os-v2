# EcoDashV3 — Night Build Tasks

## Status
- [x] Scope bepaald
- [x] Naam vastgesteld: EcoDashV3
- [x] Visuele richting bepaald (EcoHandel herkenbaar, desktop-first, later mobile)
- [x] Assets ontvangen (wordmark + favicon)
- [x] Projectstructuur opzetten
- [x] Data source audit afronden (Ads / GA4 / GSC / Shopify)
- [x] Dashboard architectuur kiezen voor lokale v1 + latere VPS/app deploy
- [ ] Logo/assets converteren en dashboard branding klaarzetten
- [x] Basis HTML/CSS/JS shell bouwen
- [x] Ads module v1 bouwen (hoogste prioriteit)
- [ ] GA4 traffic module v1 bouwen
- [x] GSC search module v1 bouwen
- [ ] Shopify omzet / orders / best sellers module v1 bouwen
- [ ] Grafieken en KPI cards toevoegen
- [x] Read-only data refresh flow bouwen
- [x] Taakprioriteiten / control-room UX finetunen
- [x] Uitlegbaar uitbreidbaar maken (modulair)
- [x] Hourly improvement job instellen
- [x] Eerste lokale preview opleveren
- [ ] Nachtelijke iteratie: elk uur verbeteren + reviewen

## Werkregels vannacht
1. Ads eerst, daarna GSC/GA4, daarna Shopify verdieping
2. Geen haastwerk dat kwaliteit sloopt
3. Elk uur meerdere verbeteringen bundelen
4. Na elke significante stap TASKS.md updaten
5. Dashboard bouwen alsof dit later de Jean Clawd control room wordt

## Huidige blockers / next best steps
- Ads live data adapter zit nu in `scripts/fetch_all.py` en schrijft direct naar `dashboard/data/ads.json`.
- GSC URL-prefix live adapter werkt nu ook; domain property blijft nog wachten op DNS TXT verificatie.
- GA4 property ID voor Data API ontbreekt nog steeds; measurement ID alleen is niet genoeg voor nette reporting.
- Shopify adapter-shell is ingebouwd, maar current token/store combinatie geeft nog `401 Unauthorized`.
- Volgende beste stap: juiste Shopify Admin API toegang fixen en daarna GA4 property ID toevoegen.
