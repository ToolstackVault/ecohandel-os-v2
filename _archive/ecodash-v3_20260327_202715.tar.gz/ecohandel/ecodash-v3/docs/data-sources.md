# EcoDashV3 Data Source Audit

## 1) Google Ads — hoogste prioriteit
**Status:** gedeeltelijk bevestigd, read-only haalbaar
- Customer ID: `592-190-7188`
- MCC: `467-369-9715`
- Lokale config aanwezig: `secrets/google-ads.yaml`
- Lokale Python 3.11 venv bekend uit memory: `.venv-googleads311`
- Bekend werkend: day metrics ophalen (impressions / clicks / cost)

**Wat v1 nu doet**
- Toont seed snapshot + readiness status
- Houdt plek vrij voor live ingest onder `dashboard/data/ads.json`

**Blocker**
- Geen directe herbruikbare EcoDash-scriptlaag gevonden in project zelf

**Next best step**
- Mini adapter toevoegen die via bestaande Ads venv een compacte JSON dumpt: spend, clicks, impressions, conversions, conversion value, campaigns

## 2) Google Search Console
**Status:** gedeeltelijk bevestigd
- Service account aanwezig: `.env/google_service_account.json`
- Toegang bevestigd voor `https://www.ecohandel.nl/`
- Domain property nog blocker (`sc-domain:ecohandel.nl` nog niet verified)

**Wat v1 nu doet**
- Toont query/page opportunity module op basis van seed data + audit notes

**Blocker**
- Domain property ontbreekt nog, dus property-scope en complete SEO monitoring zijn nog niet af

**Next best step**
- Query script bouwen voor URL-prefix property als fallback
- Later switchbaar maken naar domain property zonder UI rewrite

## 3) GA4
**Status:** tracking opgeschoond, API detail nog incompleet
- Intended measurement ID: `G-00J93RYPET`
- Dubbele meting verwijderd
- Ads ↔ GA4 link gelegd

**Wat v1 nu doet**
- Traffic/quality shell klaar met seed KPI's

**Blocker**
- Property ID voor Data API nog niet bevestigd in projectcontext

**Next best step**
- GA4 property ID achterhalen en Data API adapter toevoegen voor sessions, users, revenue, channel mix

## 4) Shopify
**Status:** read-only technisch haalbaar, nog niet in nette adapter gegoten
- Store: `n6f6ja-qr.myshopify.com`
- Admin token kan lokaal gegenereerd worden
- Data prioriteit: omzet, orders, AOV, top products

**Wat v1 nu doet**
- Shopify module staat klaar met seed placeholders en duidelijke missing-data state

**Blocker**
- Geen bestaande read-only EcoDash snapshot of exportscript gevonden in dit project

**Next best step**
- Compacte script toevoegen die laatste 7/30 dagen omzet/orders + top products naar JSON trekt

## Architectuurkeuze
Desktop-first static dashboard + lichte lokale Flask server.

Waarom dit goed is:
- snel vannacht op te leveren
- lokaal bruikbaar zonder VPS
- JSON-contracten maken latere VPS sync / Jean Clawd app wrapper simpel
- adapters kunnen later naar cron, PM2, API of Electron/Tauri shell zonder front-end rewrite
