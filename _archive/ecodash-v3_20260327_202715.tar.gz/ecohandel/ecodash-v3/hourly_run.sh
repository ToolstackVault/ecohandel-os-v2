#!/bin/zsh
set -euo pipefail

WORKDIR="/Users/ecohandel.nl/.openclaw/workspace"
PROJECT="$WORKDIR/ecohandel/ecodash-v3"
LOGDIR="$PROJECT/logs"
STAMP=$(date '+%Y-%m-%d %H:%M:%S')
mkdir -p "$LOGDIR"

{
  echo "[$STAMP] EcoDashV3 hourly cycle start"
  python3 "$PROJECT/scripts/fetch_all.py"
  python3 "$PROJECT/scripts/build_dashboard.py"
  echo "[$STAMP] Refresh complete"
  echo "[$STAMP] Current task list:"
  sed -n '1,220p' "$PROJECT/TASKS.md"
  echo "[$STAMP] EcoDashV3 hourly cycle end"
  echo
} >> "$LOGDIR/hourly.log" 2>&1
